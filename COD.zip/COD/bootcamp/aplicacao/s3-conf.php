<?php
$accessKey = '';
$secretKey = '';
$region = 'us-east-1';
$bucket = '';
$arqName =  'logo.jpg';
$linkestatico = ''
?>
